import React, { useState, useEffect } from "react";
import { ethers, BrowserProvider } from "ethers";
import { CONTRACT_ADDRESS, ABI } from "./config/contractConfig";
import './App.css';

// Define the admin address (replace with your MetaMask admin address)
const ADMIN_ADDRESS = "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266";

function App() {
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [account, setAccount] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [certificateName, setCertificateName] = useState(""); // Input for minting
  const [recipientAddress, setRecipientAddress] = useState(""); // Input for recipient address
  const [certificates, setCertificates] = useState([]); // Store certificates list
  const [verifyCertId, setVerifyCertId] = useState(""); // Input for verification
  const [verificationMessage, setVerificationMessage] = useState("");

  // Connect to MetaMask
  useEffect(() => {
    async function connectWallet() {
      if (typeof window.ethereum !== "undefined") {
        const provider = new BrowserProvider(window.ethereum);
        await provider.send("eth_requestAccounts", []);
        const signer = await provider.getSigner();
        const account = await signer.getAddress();
        setProvider(provider);
        setSigner(signer);
        setAccount(account);
        setIsAdmin(account.toLowerCase() === ADMIN_ADDRESS.toLowerCase());
      } else {
        alert("MetaMask is required to use this application.");
      }
    }

    connectWallet();
  }, []);

  // Mint Certificate (only for admin)
const mintCertificate = async () => {
  if (certificateName.trim() === "") {
    alert("Please enter a certificate name.");
    return;
  }

  const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);
  try {
    const tx = await contract.mintCertificate(recipientAddress, certificateName);
    await tx.wait();

    // Retrieve the latest certificate ID
    const latestCertificateId = await contract.certificateCounter();
    alert(`Certificate Minted Successfully! Certificate ID: ${latestCertificateId.toString()}`);

    setCertificateName(""); // Clear input
    setRecipientAddress(""); // Clear recipient address
    fetchCertificates(); // Refresh certificate list
  } catch (error) {
    console.error("Minting error:", error);
    alert("Error minting certificate.");
  }
};

  // Fetch Certificates (for listing)
const fetchCertificates = async () => {
  if (!provider) return;
  
  const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);
  try {
    const totalCertificates = await contract.certificateCounter();
    
    const certList = [];
    for (let i = 1; i <= totalCertificates; i++) {
      const cert = await contract.getCertificate(i);
      
      // Check if the user is admin or the recipient of the certificate
      if (isAdmin || cert.recipient.toLowerCase() === account.toLowerCase()) {
        certList.push({ id: i, details: cert.details, recipient: cert.recipient });
      }
    }
    setCertificates(certList);
  } catch (error) {
    console.error("Error fetching certificates:", error);
    alert("Error fetching certificates.");
  }
};


  // Verify Certificate
  const verifyCertificate = async () => {
    const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);
    try {
      const cert = await contract.getCertificate(verifyCertId);
      setVerificationMessage(cert ? "Certificate is valid." : "Certificate is invalid or not found.");
    } catch (error) {
      console.error("Verification error:", error);
      setVerificationMessage("Error verifying certificate.");
    }
  };

  return (
    <div className="App">
      <h1>Welcome to the NFT Certificate DApp</h1>
      <p>Connected to MetaMask as: {account}</p>
      {isAdmin ? (
        <>
          <h2>Admin Options</h2>
          <div className="admin-section">
            <input
              type="text"
              placeholder="Recipient Address"
              value={recipientAddress}
              onChange={(e) => setRecipientAddress(e.target.value)}
            />
            <input
              type="text"
              placeholder="Certificate Name"
              value={certificateName}
              onChange={(e) => setCertificateName(e.target.value)}
            />
            <button onClick={mintCertificate}>Mint Certificate</button>
          </div>
          <button onClick={fetchCertificates}>List All Certificates</button>
        </>
      ) : (
        <>
          <h2>User Options</h2>
          <button onClick={fetchCertificates}>List My Certificates</button>
        </>
      )}
      <div>
        <h2>Verify Certificate</h2>
        <input
          type="text"
          placeholder="Enter Certificate ID"
          value={verifyCertId}
          onChange={(e) => setVerifyCertId(e.target.value)}
        />
        <button onClick={verifyCertificate}>Verify</button>
        <p>{verificationMessage}</p>
      </div>
      <div>
        <h2>Certificate List</h2>
        {certificates.length > 0 ? (
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Recipient</th>
              </tr>
            </thead>
            <tbody>
              {certificates.map((cert) => (
                <tr key={cert.id}>
                  <td>{cert.id}</td>
                  <td>{cert.details}</td>
                  <td>{cert.recipient}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No certificates found.</p>
        )}
      </div>
    </div>
  );
}

export default App;
