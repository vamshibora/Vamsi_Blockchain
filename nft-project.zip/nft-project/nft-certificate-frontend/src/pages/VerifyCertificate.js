import React, { useState } from "react";
import { ethers } from "ethers";
import { CONTRACT_ADDRESS, ABI } from "../config/contractConfig";

function VerifyCertificate() {
  const [certificateId, setCertificateId] = useState("");
  const [verificationMessage, setVerificationMessage] = useState("");

  const verifyCertificate = async () => {
    if (typeof window.ethereum !== "undefined") {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);

      try {
        const certificate = await contract.getCertificate(certificateId);
        setVerificationMessage(
          certificate ? "Certificate is valid." : "Certificate not found."
        );
      } catch (error) {
        console.error("Error verifying certificate:", error);
        setVerificationMessage("Error verifying certificate.");
      }
    } else {
      setVerificationMessage("MetaMask is not connected");
    }
  };

  return (
    <div>
      <h2>Verify Certificate</h2>
      <input
        type="text"
        placeholder="Certificate ID"
        value={certificateId}
        onChange={(e) => setCertificateId(e.target.value)}
      />
      <button onClick={verifyCertificate}>Verify Certificate</button>
      <p>{verificationMessage}</p>
    </div>
  );
}

export default VerifyCertificate;
