import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ethers } from "ethers";
import "./Home.css";

const MAIN_USER = "0x0Aa48d79c601F0163e804fe45B39B80064Ba4068"; // Replace with your admin address

function Home() {
  const [connected, setConnected] = useState(false);
  const [currentAddress, setCurrentAddress] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const navigate = useNavigate();

  // Connect to MetaMask
  const connectWallet = async () => {
    if (typeof window.ethereum !== "undefined") {
      await window.ethereum.request({ method: "eth_requestAccounts" });
      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const address = await signer.getAddress();

      setCurrentAddress(address);
      setConnected(true);
      setIsAdmin(address.toLowerCase() === MAIN_USER.toLowerCase());

      // Redirect based on account type
      if (address.toLowerCase() === MAIN_USER.toLowerCase()) {
        navigate("/app"); // Admin view
      } else {
        navigate("/verify"); // Regular user view
      }
    } else {
      alert("Please install MetaMask to use this app.");
    }
  };

  // Auto-connect if MetaMask is already connected
  useEffect(() => {
    connectWallet();
  }, []);

  return (
    <div className="home-container">
      <h1>Welcome to the NFT Certificate DApp</h1>
      {!connected ? (
        <button onClick={connectWallet} className="connect-button">Connect MetaMask</button>
      ) : (
        <>
          <p>Connected to MetaMask as: <strong>{currentAddress}</strong></p>
          <div className="button-group">
            {isAdmin ? (
              <>
                <Link to="/mint" className="home-button">Mint Certificate</Link>
                <Link to="/verify" className="home-button">Verify Certificate</Link>
                <Link to="/certificates" className="home-button">List Certificates</Link>
              </>
            ) : (
              <>
                <Link to="/verify" className="home-button">Verify Certificate</Link>
                <Link to="/certificates" className="home-button">My Certificates</Link>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
}

export default Home;
