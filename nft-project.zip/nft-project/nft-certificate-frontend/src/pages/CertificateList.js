import React, { useEffect, useState } from "react";
import { ethers } from "ethers";
import { CONTRACT_ADDRESS, ABI } from "../config/contractConfig";

function CertificateList() {
  const [certificates, setCertificates] = useState([]);

  useEffect(() => {
    const fetchCertificates = async () => {
      if (typeof window.ethereum !== "undefined") {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, provider);
        const certificateCounter = await contract.certificateCounter();
        
        const certs = [];
        for (let i = 0; i < certificateCounter; i++) {
          const cert = await contract.getCertificate(i);
          certs.push({ id: i, details: cert.details, recipient: cert.recipient });
        }
        setCertificates(certs);
      }
    };

    fetchCertificates();
  }, []);

  return (
    <div>
      <h2>My Certificates</h2>
      <ul>
        {certificates.map((cert) => (
          <li key={cert.id}>
            <strong>ID:</strong> {cert.id} <br />
            <strong>Recipient:</strong> {cert.recipient} <br />
            <strong>Details:</strong> {cert.details} <br />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default CertificateList;
