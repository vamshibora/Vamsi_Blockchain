import React, { useState, useEffect } from 'react';

function MyCertificates() {
  const [certificates, setCertificates] = useState([]);

  useEffect(() => {
    // Fetch certificates owned by the connected account.
    setCertificates([
      { id: 1, title: 'Blockchain Basics', status: 'Valid' },
      { id: 2, title: 'Advanced Smart Contracts', status: 'Revoked' },
    ]);
  }, []);

  return (
    <div className="my-certificates">
      <h2>My Certificates</h2>
      <div className="certificates-grid">
        {certificates.map(cert => (
          <div key={cert.id} className="certificate-card">
            <h3>{cert.title}</h3>
            <p>Status: {cert.status}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default MyCertificates;