import React, { useState } from "react";
import { ethers } from "ethers";
import { CONTRACT_ADDRESS, ABI } from "../config/contractConfig";

const MintCertificate = () => {
  const [certificateName, setCertificateName] = useState("");

  const mintCertificate = async () => {
    if (typeof window.ethereum !== "undefined") {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);

      try {
        const tx = await contract.mintCertificate(await signer.getAddress(), certificateName);
        await tx.wait();
        alert("Certificate Minted Successfully!");
        setCertificateName("");
      } catch (error) {
        console.error("Error minting certificate:", error);
        alert("Failed to mint certificate.");
      }
    } else {
      alert("Please connect to MetaMask.");
    }
  };

  return (
    <div>
      <h1>Mint Certificate</h1>
      <input
        type="text"
        value={certificateName}
        onChange={(e) => setCertificateName(e.target.value)}
        placeholder="Enter certificate details"
      />
      <button onClick={mintCertificate}>Mint Certificate</button>
    </div>
  );
};

export default MintCertificate;
