const { ethers } = require("hardhat");

async function main() {
  console.log("Deploying CertificateNFT contract...");

  // Get the contract factory
  const CertificateNFT = await ethers.getContractFactory("CertificateNFT");

  // Deploy the contract and wait for it to be mined
  const certificateNFT = await CertificateNFT.deploy();
  await certificateNFT.deploymentTransaction(); // Ensures the deployment transaction is mined

  // Log the contract address
  console.log("CertificateNFT deployed to:", certificateNFT.target);
}

main().catch((error) => {
  console.error("Deployment error:", error);
  process.exitCode = 1;
});
